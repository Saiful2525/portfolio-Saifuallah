# Laravel Product API (Portfolio Project)

## Overview
This is a RESTful Product API built using Laravel.

This project demonstrates:

- RESTful API design
- CRUD operations
- Laravel Controller & Model
- Database migration
- API testing using Bruno

---

## Tech Stack

- Laravel
- PHP
- MySQL
- Bruno (API Testing)
- GitHub

---

## API Endpoints

| Method | Endpoint | Description |
|------|---------|-------------|
| GET | /api/products | Get all products |
| GET | /api/products/{id} | Get single product |
| POST | /api/products | Create product |
| PUT | /api/products/{id} | Update product |
| DELETE | /api/products/{id} | Delete product |

---

## Installation

```
composer create-project laravel/laravel product-api
```

Copy files from this repository into your project.

Setup database in .env

Run:

```
php artisan migrate
php artisan serve
```

---

## API Test Example

GET:

```
http://127.0.0.1:8000/api/products
```

---

## Screenshots

See /screenshots folder

---

## Author

Saifuallah Sarwan

Backend Developer Portfolio Project

